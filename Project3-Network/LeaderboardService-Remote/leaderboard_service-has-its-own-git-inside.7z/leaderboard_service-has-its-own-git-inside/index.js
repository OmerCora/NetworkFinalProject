var cool = require('cool-ascii-faces');
var express = require('express');
var app = express();

//database creation:  create table leaderboard (id integer, nickname text, score integer, time_added date not null default CURRENT_DATE);
//insert sample: insert into leaderboard values (1, 'Cora', 2150);


var bodyParser = require('body-parser')
app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));

app.set('port', (process.env.PORT || 5000));

app.use(express.static(__dirname + '/public'));

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/', function(request, response) {
  response.render('pages/index')
});

app.get('/cool', function(request, response) {
  response.send(cool());
});

app.listen(app.get('port'), function() {
  console.log('Node app is running on port', app.get('port'));
});

app.get('/times', function(request, response) {
    var result = ''
    var times = process.env.TIMES || 5
    for (i=0; i < times; i++)
      result += i + ' ';
  response.send(result);
});

var pg = require('pg');

//post - insert a row to leaderboard
app.post('/score/:id', function(request, response) {
    var playerid = request.params.id;

    var playerScore = request.body.score;
    var playerNickname = request.body.nickname;

    pg.connect(process.env.DATABASE_URL, function(err, client, done) {
      if (err)
      {
        console.error(err);
      }
      client.query('INSERT INTO leaderboard VALUES ($1, $2, $3) ', [playerid, playerNickname, playerScore] ,function(err, result) {
        done();
        if (err)
         { console.error(err); response.send("Error " + err); }
        else
         { response.render('pages/db', {results: result.rows} ); }
      });
    });

});

//get a single row by ID
app.get('/score/:id', function(request, response) {
    var playerid = request.params.id;

    pg.connect(process.env.DATABASE_URL, function(err, client, done) {
      if (err)
      {
        console.error(err);
      }
      client.query('SELECT * FROM leaderboard WHERE id = $1 LIMIT 10', [playerid] ,function(err, result) {
        done();
        if (err)
         { console.error(err); response.send("Error " + err); }
        else
         { response.render('pages/db', {results: result.rows} ); }
      });
    });

    // ...
});


//get leadderboard
app.get('/score', function (request, response) {

  console.log("DATABASE URL :   ");
  console.log(process.env.DATABASE_URL);
  console.log("   ]]]");
  pg.connect(process.env.DATABASE_URL, function(err, client, done) {
    if (err)
    {
      console.error(err);
    }
    client.query('SELECT * FROM leaderboard ORDER BY score DESC LIMIT 10', function(err, result) {
      done();
      if (err)
       { console.error(err); response.send("Error " + err); }
      else
       { response.render('pages/db', {results: result.rows} ); }
    });
  });
});
